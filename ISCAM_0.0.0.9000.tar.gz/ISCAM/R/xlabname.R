xlabname <- function(x){
  deparse(substitute(x))
}